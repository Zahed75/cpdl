import 'package:flutter/material.dart';

import '../../utils/constants/sizes.dart';

class UPadding {
  UPadding._();

  static const EdgeInsetsGeometry screenPadding = EdgeInsets.all(
    USizes.defaultSpace,
  );
}
